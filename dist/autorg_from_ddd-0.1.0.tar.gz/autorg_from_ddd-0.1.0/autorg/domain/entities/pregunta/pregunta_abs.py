class Pregunta_ABS:

    def __init__(self,pregunta:str):
        self.pregunta = pregunta

    def get_question(self):
        pass
