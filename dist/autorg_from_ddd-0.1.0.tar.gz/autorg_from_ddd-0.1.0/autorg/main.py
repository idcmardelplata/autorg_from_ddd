def main():
    print("Build success")

main()
