def main():
    print("Build success")
