# Autorg

An automatic individual input-resources managment

## Methodologies

It's being created using Agile methodologies, such as tdd and continuous integration.
Also its arch is being designed by ddd.
