# Significado es una entidad debido a que sera rastreada mediante el flujo de procesamiento.
class Significado_ABS:
    def __init__(self,significado:str):
        self.significado = significado
